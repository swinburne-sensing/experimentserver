/**
 * Created by hustcc on 18/5/20.
 * Contract: i@hust.cc
 */

export { format } from './format';
export { render, cancel } from './realtime';
export { register } from './locales';
