export default function(number: number, index: number): [string, string] {
  return [
    ['nett no', 'om litt'],
    ['%s sekund sidan', 'om %s sekund'],
    ['1 minutt sidan', 'om 1 minutt'],
    ['%s minutt sidan', 'om %s minutt'],
    ['1 time sidan', 'om 1 time'],
    ['%s timar sidan', 'om %s timar'],
    ['1 dag sidan', 'om 1 dag'],
    ['%s dagar sidan', 'om %s dagar'],
    ['1 veke sidan', 'om 1 veke'],
    ['%s veker sidan', 'om %s veker'],
    ['1 månad sidan', 'om 1 månad'],
    ['%s månadar sidan', 'om %s månadar'],
    ['1 år sidan', 'om 1 år'],
    ['%s år sidan', 'om %s år'],
  ][index] as [string, string];
}
