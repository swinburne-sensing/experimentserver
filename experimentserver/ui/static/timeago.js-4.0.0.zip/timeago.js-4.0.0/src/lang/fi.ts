export default function(number: number, index: number): [string, string] {
  return [
    ['juuri äsken', 'juuri nyt'],
    ['%s sekuntia sitten', '%s sekunnin päästä'],
    ['minuutti sitten', 'minuutin päästä'],
    ['%s minuuttia sitten', '%s minuutin päästä'],
    ['tunti sitten', 'tunnin päästä'],
    ['%s tuntia sitten', '%s tunnin päästä'],
    ['päivä sitten', 'päivän päästä'],
    ['%s päivää sitten', '%s päivän päästä'],
    ['viikko sitten', 'viikon päästä'],
    ['%s viikkoa sitten', '%s viikon päästä'],
    ['kuukausi sitten', 'kuukauden päästä'],
    ['%s kuukautta sitten', '%s kuukauden päästä'],
    ['vuosi sitten', 'vuoden päästä'],
    ['%s vuotta sitten', '%s vuoden päästä'],
  ][index] as [string, string];
}
